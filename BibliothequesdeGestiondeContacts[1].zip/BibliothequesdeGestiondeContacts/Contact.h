#ifndef CONTACT_H
#define CONTACT_H

#include <iostream>
#include <string> // Elle permet de manipuler des cha�ne de caractere

class Contact {  // Ici on a defini une classe contact
private:  // ces des attribue priver qui contienne des informations personnelles du contacts, elle permet de proteger les donn�� et eviter les modification accidentel
    std::string nom;
    std::string telephone;
    std::string email;
    std::string adresse;

public:
    // Constructeurs
    Contact() = default; // Constructeur par d�faut qui initialise un contact sans donner
    Contact(const std::string& n, const std::string& t, const std::string& e, const std::string& a);

    // Accesseurs
    std::string getNom() const; // c'est une fonction appeler getter qui permet de retourner ici le nom, telephone, email, adresse
    std::string getTelephone() const;
    std::string getEmail() const;
    std::string getAdresse() const;

    // Modificateurs
    void setTelephone(const std::string& p);
    void setEmail(const std::string& e);
    void setAdresse(const std::string& a);

    // Afficher le contact
    void display() const;

    // Conversion en texte et depuis texte
    std::string toString() const; // elle permet de convertir un contact en texte
    static Contact fromString(const std::string& data); // Reconstruire un contact a partir d'un texte sauvegarder
};

#endif // CONTACT_H

