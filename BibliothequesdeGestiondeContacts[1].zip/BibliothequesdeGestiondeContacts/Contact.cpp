#include "Contact.h"
#include <sstream>

// Constructeur avec param�tres
Contact::Contact(const std::string& n, const std::string& t, const std::string& e, const std::string& a)
    : nom(n), telephone(t), email(e), adresse(a) {}

// Accesseurs
std::string Contact::getNom() const { return nom; }
std::string Contact::getTelephone() const { return telephone; }
std::string Contact::getEmail() const { return email; }
std::string Contact::getAdresse() const { return adresse; }

// Modificateurs
void Contact::setTelephone(const std::string& p) { telephone = p; }
void Contact::setEmail(const std::string& e) { email = e; }
void Contact::setAdresse(const std::string& a) { adresse = a; }

// Afficher un contact
void Contact::display() const {
    std::cout << "Nom: " << nom << "\n"
              << "T�l�phone: " << telephone << "\n"
              << "Email: " << email << "\n"
              << "Adresse: " << adresse << "\n";
}

// Convertir un contact en texte
std::string Contact::toString() const {
    return nom + ";" + telephone + ";" + email + ";" + adresse;
}

// Cr�er un contact � partir d'un texte
Contact Contact::fromString(const std::string& data) {
    std::istringstream ss(data);
    std::string n, t, e, a;

    std::getline(ss, n, ';');
    std::getline(ss, t, ';');
    std::getline(ss, e, ';');
    std::getline(ss, a, ';');

    return Contact(n, t, e, a);
}
