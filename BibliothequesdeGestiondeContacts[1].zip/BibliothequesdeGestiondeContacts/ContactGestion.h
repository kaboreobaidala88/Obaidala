#ifndef CONTACTGESTION_H
#define CONTACTGESTION_H

#include "Contact.h"
#include <vector>

class ContactGestion {
private:
    std::vector<Contact> contacts;

public:
    void addContact();
    void modifyContact();
    void deleteContact();
    void searchContact() const;
    void sortContacts();
    void saveToFile() const;
    void loadFromFile();
    void displayContacts() const;
};

#endif // CONTACTGESTION_H
