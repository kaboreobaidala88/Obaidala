#include "ContactGestion.h"
#include <iostream>

int main() {
    ContactGestion gestion;
    int choix;

    do {
        std::cout << "\n*** Gestion de Contacts ***\n";
        std::cout << "1. Ajouter un contact\n";
        std::cout << "2. Modifier un contact\n";
        std::cout << "3. Supprimer un contact\n";
        std::cout << "4. Rechercher un contact\n";
        std::cout << "5. Trier les contacts\n";
        std::cout << "6. Sauvegarder les contacts\n";
        std::cout << "7. Charger les contacts\n";
        std::cout << "8. Quitter\n";
        std::cout << "Choisissez une option : ";
        std::cin >> choix;
        std::cin.ignore(); // Ignorer le retour � la ligne apr�s l'entr�e

        switch (choix) {
        case 1:
            gestion.addContact();
            break;
        case 2:
            gestion.modifyContact();
            break;
        case 3:
            gestion.deleteContact();
            break;
        case 4:
            gestion.searchContact();
            break;
        case 5:
            gestion.sortContacts();
            break;
        case 6:
            gestion.saveToFile();
            break;
        case 7:
            gestion.loadFromFile();
            break;
        case 8:
            std::cout << "Au revoir !\n";
            break;
        default:
            std::cout << "Option invalide. Veuillez reessayer.\n";
        }
    } while (choix != 8);

    return 0;
}
