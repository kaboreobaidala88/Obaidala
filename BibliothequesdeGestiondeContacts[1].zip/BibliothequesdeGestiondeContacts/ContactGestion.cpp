#include "ContactGestion.h"
#include <iostream>
#include <fstream>
#include <algorithm>

// Ajouter un contact avec validation des donn�es
void ContactGestion::addContact() {
    std::string nom, telephone, email, adresse;

    std::cout << "Entrer le nom : ";
    std::getline(std::cin, nom);

    // Validation du num�ro de t�l�phone
    do {
        std::cout << "Entrer le numero de telephone (uniquement des chiffres) : ";
        std::getline(std::cin, telephone);
        if (!std::all_of(telephone.begin(), telephone.end(), ::isdigit)) {
            std::cout << "Erreur : Le numero doit contenir uniquement des chiffres.\n";
        } else {
            break;
        }
    } while (true);

    // Validation de l'email
    do {
        std::cout << "Entrer votre email (doit contenir '@gmail.com') : ";
        std::getline(std::cin, email);
        if (email.find("@gmail.com") == std::string::npos) {
            std::cout << "Erreur : L'email doit contenir '@gmail.com'.\n";
        } else {
            break;
        }
    } while (true);

    std::cout << "Entrer l'adresse : ";
    std::getline(std::cin, adresse);

    contacts.emplace_back(nom, telephone, email, adresse);
    std::cout << "Contact ajoute avec succes.\n";
}

// Modifier un contact
void ContactGestion::modifyContact() {
    std::string nom;
    std::cout << "Entrer le nom du contact a modifier : ";
    std::getline(std::cin, nom);

    for (auto& contact : contacts) {
        if (contact.getNom() == nom) {
            std::string telephone, email, adresse;

            do {
                std::cout << "Entrer le nouveau numero de telephone : ";
                std::getline(std::cin, telephone);
                if (!std::all_of(telephone.begin(), telephone.end(), ::isdigit)) {
                    std::cout << "Erreur : Le numero doit contenir uniquement des chiffres.\n";
                } else {
                    break;
                }
            } while (true);

            do {
                std::cout << "Entrer le nouveau email (doit contenir '@gmail.com') : ";
                std::getline(std::cin, email);
                if (email.find("@gmail.com") == std::string::npos) {
                    std::cout << "Erreur : L'email doit contenir '@gmail.com'.\n";
                } else {
                    break;
                }
            } while (true);

            std::cout << "Entrer la nouvelle adresse : ";
            std::getline(std::cin, adresse);

            contact.setTelephone(telephone);
            contact.setEmail(email);
            contact.setAdresse(adresse);

            std::cout << "Contact modifie avec succes.\n";
            return;
        }
    }

    std::cout << "Contact non trouve.\n";
}

// Supprimer un contact
void ContactGestion::deleteContact() {
    std::string nom;
    std::cout << "Entrer le nom du contact a supprimer : ";
    std::getline(std::cin, nom);

    auto it = std::remove_if(contacts.begin(), contacts.end(),
                             [&nom](const Contact& contact) { return contact.getNom() == nom; });

    if (it != contacts.end()) {
        contacts.erase(it, contacts.end());
        std::cout << "Contact supprime avec succes.\n";
    } else {
        std::cout << "Contact non trouve.\n";
    }
}

// Rechercher un contact
void ContactGestion::searchContact() const {
    std::string nom;
    std::cout << "Entrer le nom a rechercher : ";
    std::getline(std::cin, nom);

    bool found = false;
    for (const auto& contact : contacts) {
        if (contact.getNom().find(nom) != std::string::npos) {
            contact.display();
            found = true;
        }
    }

    if (!found) {
        std::cout << "Aucun contact trouve.\n";
    }
}

// Afficher tous les contacts
void ContactGestion::displayContacts() const {
    if (contacts.empty()) {
        std::cout << "Aucun contact a afficher.\n";
        return;
    }

    for (const auto& contact : contacts) {
        contact.display();
        std::cout << "---------------------------\n";
    }
}

// Trier les contacts par nom
void ContactGestion::sortContacts() {
    std::sort(contacts.begin(), contacts.end(),
              [](const Contact& a, const Contact& b) { return a.getNom() < b.getNom(); });
    std::cout << "Contacts tries avec succes.\n";
}

// Sauvegarder les contacts dans un fichier
void ContactGestion::saveToFile() const {
    std::ofstream file("contacts.txt");
    if (!file) {
        std::cout << "Erreur lors de l'ouverture du fichier.\n";
        return;
    }

    for (const auto& contact : contacts) {
        file << contact.toString() << "\n";
    }

    file.close();
    std::cout << "Contacts sauvegardes avec succes.\n";
}

// Charger les contacts depuis un fichier
void ContactGestion::loadFromFile() {
    std::ifstream file("contacts.txt");
    if (!file) {
        std::cout << "Erreur lors de l'ouverture du fichier.\n";
        return;
    }

    contacts.clear();
    std::string line;
    while (std::getline(file, line)) {
        contacts.push_back(Contact::fromString(line));
    }

    file.close();
    std::cout << "Contacts charges avec succes.\n";
}

